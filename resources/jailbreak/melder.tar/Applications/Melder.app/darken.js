(function () {
    var W = window, D = document;
    if (W.__melderDarken) {
        W.__melderDarken();
        return;
    }
    var dark = null;

    var memoBg = {}, memoFg = {}, memoBorder = {};
    var FLAT = '#242424';
    var SKIP = { IMG: 1, VIDEO: 1, CANVAS: 1, IFRAME: 1, EMBED: 1, OBJECT: 1, SCRIPT: 1, STYLE: 1, svg: 1, SVG: 1, PICTURE: 1 };

    function rgb(s) {
        if (!s || s === 'transparent') return null;
        var m = s.match(/[\d.]+/g);
        if (!m || m.length < 3) return null;
        return [+m[0], +m[1], +m[2], m.length > 3 ? +m[3] : 1];
    }
    function lum(c) {
        return (0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2]) / 255;
    }
    function hsl(c) {
        var r = c[0] / 255, g = c[1] / 255, b = c[2] / 255;
        var mx = Math.max(r, g, b), mn = Math.min(r, g, b), d = mx - mn;
        var h = 0, s = 0, l = (mx + mn) / 2;
        if (d) {
            s = l > 0.5 ? d / (2 - mx - mn) : d / (mx + mn);
            if (mx === r) h = (g - b) / d + (g < b ? 6 : 0);
            else if (mx === g) h = (b - r) / d + 2;
            else h = (r - g) / d + 4;
            h /= 6;
        }
        return [h, s, l];
    }
    function css(h, s, l, a) {
        return 'hsla(' + Math.round(h * 360) + ',' + Math.round(s * 100) + '%,' + Math.round(l * 100) + '%,' + a + ')';
    }
    function bgOf(e) {
        var c = e ? rgb(W.getComputedStyle(e, null).backgroundColor) : null;
        return c && c[3] > 0 ? c : null;
    }

    function pageIsDark() {
        var metas = D.getElementsByTagName('meta'), i;
        for (i = 0; i < metas.length; i++) {
            if ((metas[i].getAttribute('name') || '').toLowerCase() === 'color-scheme') {
                var v = (metas[i].getAttribute('content') || '').toLowerCase();
                if (v.indexOf('dark') >= 0 && v.indexOf('light') < 0) return true;
            }
        }
        var bg = bgOf(D.body) || bgOf(D.documentElement);
        if (bg) return lum(bg) < 0.4;
        var fg = rgb(W.getComputedStyle(D.body, null).color);
        return fg ? lum(fg) > 0.6 : false;
    }

    function toBg(str) {
        var c = rgb(str), h;
        if (!c || c[3] <= 0) return '';
        h = hsl(c);
        return h[2] > 0.4 ? css(h[0], h[1], 0.12 + (1 - h[2]) * 0.35, c[3]) : '';
    }
    function toFg(str) {
        var c = rgb(str), h;
        if (!c) return '';
        h = hsl(c);
        return h[2] < 0.6 ? css(h[0], h[1], 0.88 - h[2] * 0.35, c[3]) : '';
    }
    function toBorder(str) {
        var c = rgb(str), h;
        if (!c || c[3] <= 0) return '';
        h = hsl(c);
        return h[2] > 0.5 ? css(h[0], h[1], 0.45 - (h[2] - 0.5) * 0.5, c[3]) : '';
    }

    function mapped(memo, value, convert) {
        var result = memo[value];
        if (result === undefined) result = memo[value] = convert(value);
        return result;
    }

    function run() {
        if (!D.body) return;
        if (dark === null) dark = pageIsDark();
        if (dark) return;
        var all = D.body.getElementsByTagName('*'), list = [D.documentElement, D.body], i, n, e;
        for (i = 0, n = all.length; i < n; i++) list[list.length] = all[i];

        var work = [], st, v;
        for (i = 0, n = list.length; i < n; i++) {
            e = list[i];
            if (SKIP[e.tagName]) continue;
            st = W.getComputedStyle(e, null);
            if (!st) continue;

            v = st.backgroundImage;
            var flat = v && v !== 'none' && (v.indexOf('gradient') >= 0 || e === D.body || e === D.documentElement);
            var bg = v && v !== 'none' && !flat ? '' : mapped(memoBg, st.backgroundColor, toBg);
            var fg = mapped(memoFg, st.color, toFg);
            var border = mapped(memoBorder, st.borderTopColor, toBorder);
            if (flat || bg || fg || border) work[work.length] = [e, bg, fg, border, flat];
        }
        for (i = 0, n = work.length; i < n; i++) {
            var w = work[i], s = w[0].style;
            if (w[4]) {
                s.setProperty('background-image', 'none', 'important');
                s.setProperty('background-color', w[1] || FLAT, 'important');
            } else if (w[1]) s.setProperty('background-color', w[1], 'important');
            if (w[2]) s.setProperty('color', w[2], 'important');
            if (w[3]) s.setProperty('border-color', w[3], 'important');
        }
        var root = D.documentElement;
        if (!bgOf(root) && !bgOf(D.body)) root.style.setProperty('background-color', FLAT, 'important');
    }

    W.__melderDarken = run;
    if (D.body) run();
    else if (D.addEventListener) D.addEventListener('DOMContentLoaded', run, false);
}());
