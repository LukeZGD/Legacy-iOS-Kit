#!/bin/bash
/Applications/FourThree.app/kloader_ios5 /LLB
